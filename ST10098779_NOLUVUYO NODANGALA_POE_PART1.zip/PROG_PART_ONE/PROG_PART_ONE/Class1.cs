﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG_PART_ONE
{
   

    internal class Recipe
    {
        //declaration of variables
        private string Name;
        
        private string unitOfMeasurement;
        private int numOfSteps;
        private string Description;
        private string empty = "_";

        public int Ingredients;

        private double Quantity;
        private double half = 0.5;
        private double Do_uble = 2;
        private double triple = 3;
        
        private double sum;
        private double resetvalue = 0;

        public void Menu()
        {
            //Console.WriteLine("Welcome to your recipe App!");
            Console.WriteLine("******************************");
            Console.WriteLine("Please select your menu:"
             + "\n1. Enter Recipe"
             + "\n2. Scale Factor" 
             + "\n3. Display Recipe" 
             + "\n4. Reset Quantity" 
             + "\n5. Clear Recipe" 
             + "\n6. Exit Application");

            int menu = Convert.ToInt32(Console.ReadLine());

            switch (menu)
            {
                default:
                    Console.WriteLine("Invalid option");
                    break;
                case 1:
                    EnterRecipe();
                    break;
                case 2:
                    ScaleFactor();
                    break;
                case 3:
                    DisplayRecipe();
                    break;
                case 4:
                    ResetQuantity();
                    break;
                case 5:
                    
                    clearRecipe();
                    break;
                case 6:
                    ExitApplication();
                    break;
            }
        }

        public void EnterRecipe()
        {
            
            //add num of ingredients
            Console.WriteLine("How many ingredients do you want to add:");
            Ingredients = Convert.ToInt32(Console.ReadLine());

            string[] noOfIngredients = new string[Ingredients];//arrays to store ingredients
            string[] Steps = new string[numOfSteps];
            double[] Quantities = new double[0];

            //for loop
            for (int i = 0; i < Ingredients; i++)
            {
               
                Console.WriteLine("Enter the name of your ingredients:");//prompts the user to enter the name 
                Name = Console.ReadLine();
                noOfIngredients[i] = Name;

                Console.WriteLine("Enter the quantity for your ingredients:");//prompts the user to enter the quantity
                Quantity = Convert.ToDouble(Console.ReadLine());
                //Quantities[i] = Quantity;

                Console.WriteLine("Enter the unit Of Measurement for your ingredients:"); //enter the unit of measuremnt
                unitOfMeasurement = Console.ReadLine();
                noOfIngredients[i] = unitOfMeasurement;

                Console.WriteLine("Please enter the number of steps for your description:");//enter the number of steps
                numOfSteps = int.Parse(Console.ReadLine());
                //Steps[i] = numOfSteps;
            
                for (int m = 0; m < numOfSteps; m++)//for loop for the number of steps
                {
                    Console.WriteLine("Please enter the description of your steps:"); //prompts user to enter description
                    Description = Console.ReadLine();

                }
            }
                Console.WriteLine("Would you like to view your details:"
                + "\n1. View Details"
                + "\n2. Return to menu"
                + "\n3. Exit Application");
                int view = Convert.ToInt32(Console.ReadLine());

                //switch case method
                switch (view)
                {
                default:
                    Console.WriteLine("Invalid option");
                    break;
                    case 1:
                        DisplayRecipe();
                        break;
                    case 2:
                        Menu();
                        break;
                }

            
        }
        public void DisplayRecipe()
        {
            //displays the recipe details
            Console.WriteLine("Recipe Details:");
            Console.WriteLine("Number of Ingredients: " + Ingredients);
            Console.WriteLine("Name: " + Name);
            Console.WriteLine("Quantity: " + Quantity);
            Console.WriteLine("Unit of measurement: " + unitOfMeasurement);
            Console.WriteLine("Number of steps: " + numOfSteps);
            Console.WriteLine("Description of steps: " + Description);
            Console.WriteLine("Scale Factor:" + sum);
            Console.WriteLine("******************************");


            //asks the user whether they would like to proceed using the app or not
            Console.WriteLine("Would you like to proceed with the recipe app :"
         + "\n1. Yes (Return to the menu)"
         + "\n2. No (Exit Application)");

            int Return = Convert.ToInt32(Console.ReadLine());
            switch (Return)
            {
                case 1:
                    Menu();
                    break;
                case 2:
                    ExitApplication();
                    break;
            }

        }
        public void ScaleFactor()
        {

            //calculates scale factor , user chooses an option
            Console.WriteLine("Please select a scale factor:"
             + "\n1. 0.5(half)"
             + "\n2. 2(double)"
             + "\n3. 3(triple)");
            int scale = Convert.ToInt32(Console.ReadLine());


            if (scale == 1)
            {

                sum = Quantity * half;
                Console.WriteLine("Scale factor is:" + sum); 
                Menu();
            }
            else if (scale == 2)
            {

                sum = Quantity * Do_uble;
                Console.WriteLine("Scale factor is:" + sum);
                Menu();
            }
            if (scale == 3)
            {

                sum = Quantity * triple;
                Console.WriteLine("Scale factor is:" + sum);
                Menu();
            }
        }
        public void clearRecipe()
        {
            
            Name = empty;
            
            unitOfMeasurement = empty;
            Description = empty;
            
            // clearing method 
            Console.Clear();
            Name = empty;
            Quantity = resetvalue;
            unitOfMeasurement = empty;
            
            Description = empty;

            Console.WriteLine("Are you sure you to clear your recipe?!"
                +"\n1. Yes" +
                "\n2. No");
            int clear = Convert.ToInt32(Console.ReadLine());

            if (clear == 1)
            {
                Console.WriteLine("Number of ingredients:" + Name);
                Console.WriteLine("Name:" + Name);
                Console.WriteLine("Quantity:" + resetvalue);
                Console.WriteLine("Unit Measurement:" + unitOfMeasurement);
                Console.WriteLine("Number of steps:" + numOfSteps);
                Console.WriteLine("Description:" + Description);
                Console.WriteLine("Your data has been successfully cleared!");
                Console.WriteLine("****************************************");
                Console.WriteLine("Would you like to enter a new recipe:"+
                    "\n1. Yes(Enter new recipe)"
                    +"\n2. Return to menu"
                    +"\n3. Exit App");
                int newRecipe = Convert.ToInt32(Console.ReadLine());

                switch (newRecipe)
                {
                    case 1:
                        EnterRecipe();
                        break;
                    case 2:
                        Menu();
                        break;
                    case 3:
                        ExitApplication();
                        break;
                }

            }
            if (clear == 2)
            {
                Menu();
            }
        }


        public void ResetQuantity()
        {
            //it resets your quantit back to the original value
            Console.WriteLine("Would you like to reset your Quantity:"
            + "\n1. Yes"
            + "\n2. No");

            int originalValue = Convert.ToInt32(Console.ReadLine());
            switch (originalValue)
            {
                case 1:
                    //Quantity = resetvalue;
                    resetvalue = Quantity;


                    Console.WriteLine("Original value: " + resetvalue);
                    Menu();
                    break;
                    

                case 2:
                    Console.WriteLine("Would you like to proceed to print, main menu or exit the app:"
                        + "\n1. Return to menu" +
                        "\n2. Exit Application");
                    int Return = Convert.ToInt32(Console.ReadLine());
                    if (Return == 1)
                    {
                        Menu();
                    }
                    else
                    {
                        ExitApplication();
                    }
                    break;
            }

        }
        public void ExitApplication()
        {
            //exits your application
            Console.WriteLine("Thank you for using our Application, we hope to see you soon!");

           
            }
        }
    }







