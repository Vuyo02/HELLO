﻿// See https://aka.ms/new-console-template for more information
using System;

namespace PROG_PART_ONE
{
    class Program
    {
        static void Main(String[] args)
        {
           
            //object calling my methods from another class
            Recipe myRec = new Recipe();
            myRec.Menu();
        }
    }
}